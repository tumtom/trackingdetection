for i=1:10
    Ai{i} = learn_Ai(5,2*3*i);
end

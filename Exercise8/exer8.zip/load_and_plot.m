load('res/data1.mat')
plot_data(dat);